
//for
// let i = 0
// for (i; i < 5;) {
//     console.log(i)
// }

//while
let i = 0
let isTrue = true
while (isTrue) {
    console.log(isTrue)
    break;
}

// do {
//     i++
//     console.log('isi')
// }
// while (i < 5)