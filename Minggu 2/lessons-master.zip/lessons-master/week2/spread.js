const hobby = ['swimming','gaming']

const newHobbies = [...hobby, 'hiking','byclying']

console.log(newHobbies) 