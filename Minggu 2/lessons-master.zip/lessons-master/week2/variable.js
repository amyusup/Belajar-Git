// console.log(satu)
console.log(tiga)

var satu = 'satu'
let dua = 'dua'
const tiga = 'tiga'


// tiga = 'mengubah const'

console.log(tiga)