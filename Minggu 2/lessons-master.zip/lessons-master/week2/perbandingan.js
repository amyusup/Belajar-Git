const sekolah = 'SMK'
const string = '0'
const number = 1


// if(string === 0) {
//     console.log('iya')
// }else{
//     console.log('tidak')
// }

// if(string !== 1) {
//     console.log('iya')
// }else{
//     console.log('tidak')
// }

// if(number > 1) {
//     console.log('iya')
// }else{
//     console.log('tidak')
// }
// if(number < 1) {
//     console.log('iya')
// }else{
//     console.log('tidak')
// }

// if(number >= 1) {
//     console.log('iya')
// }else{
//     console.log('tidak')
// }

if(number <= 1) {
    console.log('iya')
}else{
    console.log('tidak')
}


