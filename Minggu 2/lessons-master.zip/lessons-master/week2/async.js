setTimeout(()=>(
    console.log('ini kode 1')
), 1000)

console.log('ini kode 2')