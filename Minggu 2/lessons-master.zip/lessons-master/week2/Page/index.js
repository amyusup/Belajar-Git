// import Components from './components/'
const Components = require('./components/components')



const Page = (nama) =>{
    console.log(nama)
}


Page(Components)