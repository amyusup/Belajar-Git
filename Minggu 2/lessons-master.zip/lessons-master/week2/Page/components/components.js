export const Components = () =>{
    console.log('aha')
}

export default Components