const nama = 'Anjas'
const sekolah = 'SMK'



// console.log('nama: ' + nama + ' Sekolah ' + sekolah)
console.log(`nama: ${nama}, Sekolah: ${sekolah}`)

